namespace server.Enum
{
    public enum PaymentStatus
    {
        Pending,
        Completed,
        Failed,
        Refund
    }
}