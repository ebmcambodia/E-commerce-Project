﻿using server.Entities;

namespace server.Interface.Repository
{
    public interface IImageRepository:IGenericRepository<Image>
    {
    }
}
