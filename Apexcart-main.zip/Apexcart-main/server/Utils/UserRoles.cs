namespace server.Utils
{
    public enum UserRoles
    {
        USER,
        ADMIN
    }
}