export const environment = {
    baseApi:'https://localhost:7174/api',
    imageBaseApi:'https://localhost:7174/',
    razorPayKey:''
};
