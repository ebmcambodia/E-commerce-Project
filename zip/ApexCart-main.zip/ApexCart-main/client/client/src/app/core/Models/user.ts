export interface UserDto {
    userId: number;
    userName: string;
    email: string;
    role: string;
    address: string;
}