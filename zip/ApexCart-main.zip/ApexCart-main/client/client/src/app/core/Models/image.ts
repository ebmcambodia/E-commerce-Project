export interface ImageDtoRes {
    id: number;
    imageUrl: string;
}