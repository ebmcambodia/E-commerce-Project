import { InjectionToken } from "@angular/core";

export const BASE_API = new InjectionToken<string>('');
export const BASE_IMAGE_API = new InjectionToken<string>('');