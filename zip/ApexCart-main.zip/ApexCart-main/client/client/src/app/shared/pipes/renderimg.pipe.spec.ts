import { RenderimgPipe } from './renderimg.pipe';

describe('RenderimgPipe', () => {
  it('create an instance', () => {
    const pipe = new RenderimgPipe();
    expect(pipe).toBeTruthy();
  });
});
