﻿using server.Entities;

namespace server.Interface.Repository
{
    public interface IWishListItemRepository:IGenericRepository<WishlistItem>
    {
    }
}
